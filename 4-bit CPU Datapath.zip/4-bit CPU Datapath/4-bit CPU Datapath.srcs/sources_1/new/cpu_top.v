`timescale 1ns / 1ps

module cpu_top (
    input wire clk,
    input wire rst,
    
    output wire [3:0] pc_out,
    output wire [11:0] instr_out,
    output wire [3:0] alu_out,
    output wire [3:0] wb_data_out,
    output wire zero_out,
    output wire carry_out
);

    // ==========================================
    // Wires Declaration
    // ==========================================
    
    // STAGE 1: IF (Fetch) Wires
    wire [3:0] if_pc, if_pc_next;
    wire [11:0] if_instr;
    wire ex_pc_sel, ex_flush; 
    wire ex_is_jmp, ex_is_jz;

    // STAGE 2: ID (Decode) Wires
    wire [3:0] id_pc;
    wire [11:0] id_instr;
    wire id_valid;
    wire [2:0] id_alu_ctrl; 
    wire id_alu_src_sel;
    wire id_mem_we;
    wire id_wb_sel;
    wire id_reg_we;
    wire id_zero_we;
    wire id_carry_we;
    wire id_is_jmp;
    wire id_is_jz;

    // STAGE 3: EX (Execute) Wires 
    wire [3:0] ex_pc;
    wire [2:0] ex_alu_ctrl; 
    wire [3:0] ex_qa;          // Data coming from Register File Port A
    wire [3:0] ex_qb;          // Data coming from Register File Port B
    wire [3:0] ex_imm;         // Immediate value extracted from instruction
    wire ex_alu_src_sel;       // Control signal for Operand MUX
    wire [3:0] ex_alu_b;       // Output of OP MUX, going into ALU Port B
    wire [3:0] ex_alu_result;  // Math result leaving the ALU
    wire ex_carry;             // Carry flag leaving the ALU
    wire ex_zero;              // Zero flag leaving the ALU
    wire ex_mem_we;            // Control signal to enable RAM write
    wire [3:0] ex_mem_read_data; // Data leaving the Data Memory
    wire ex_wb_sel;            // Control signal for Write-Back MUX
    wire [3:0] ex_wb_data;     // Output of WB MUX, going back to Register File
    wire ex_reg_we;            // Control signal to enable Register File write
    wire [1:0] ex_wa;          // Write Address for Register File
    wire ex_zero_we;           // Control signal to enable Zero Flag write
    wire ex_carry_we;          // Control signal to enable Carry Flag write
    wire [1:0] ex_rs;

    // Output assignments to view in tb
    assign pc_out = if_pc;
    assign instr_out = if_instr;
    assign alu_out = ex_alu_result;
    assign wb_data_out = ex_wb_data;
    // Removed the direct assign for zero_out and carry_out here so the register can drive them

    // ==========================================
    // Module Instantiation
    // ==========================================

    // --- STAGE 1: FETCH ---
    wire [3:0] pc_plus_1;
    assign pc_plus_1 = if_pc + 4'd1;

    mux2 pc_mux (
        .in0(pc_plus_1),
        .in1(ex_imm),       // Jump address comes from the EX stage immediate
        .sel(ex_pc_sel),
        .out(if_pc_next)
    );
    program_counter PC (
        .clk(clk), .rst(rst), .pc_en(1'b1),
        .pc_next(if_pc_next), .pc_out(if_pc)
    );
    
    instruction_memory IMEM (
        .address(if_pc), .instruction(if_instr)
    );

    // --- PIPELINE BOUNDARY: IF/ID REGISTER ---
    instruction_register IF_ID (
        .clk(clk), .rst(rst), .ir_load(1'b1), 
        .flush(ex_flush), 
        .pc_in(if_pc), .instruction_in(if_instr),
        .pc_out(id_pc), .instruction_out(id_instr), .valid_out(id_valid)
    );

    // --- STAGE 2: DECODE ---
    control_unit CU (
        .opcode(id_instr[11:8]), 
        .zero_flag(zero_out), .ex_is_jmp(ex_is_jmp), .ex_is_jz(ex_is_jz),
        .alu_ctrl(id_alu_ctrl),
        .alu_src_sel(id_alu_src_sel),
        .mem_we(id_mem_we),
        .wb_sel(id_wb_sel),
        .reg_we(id_reg_we),
        .zero_we(id_zero_we),
        .carry_we(id_carry_we),
        .is_jmp(id_is_jmp),     // Drives ID/EX register
        .is_jz(id_is_jz),       // Drives ID/EX register
        .pc_sel(ex_pc_sel),     // Drives PC MUX
        .flush(ex_flush)        // Flushes pipeline registers
    );

    // --- PIPELINE BOUNDARY: ID/EX REGISTER ---
    pipeline_register ID_EX (
        .clk(clk), .rst(rst), .flush(ex_flush),
        
        // Inputs from ID stage
        .id_alu_ctrl(id_alu_ctrl), 
        .id_alu_src_sel(id_alu_src_sel),
        .id_wb_sel(id_wb_sel),

        // If id_valid is 0, these signals are forced to 0, preventing ghost execution.
        .id_reg_we(id_reg_we & id_valid),
        .id_mem_we(id_mem_we & id_valid),
        .id_zero_we(id_zero_we & id_valid),
        .id_carry_we(id_carry_we & id_valid),
        .id_is_jmp(id_is_jmp & id_valid),
        .id_is_jz(id_is_jz & id_valid),
        
        .id_pc(id_pc),
        .id_rd(id_instr[7:6]),
        .id_rs(id_instr[5:4]),
        .id_imm(id_instr[3:0]),
        .id_valid(id_valid),
        
        // Outputs to EX stage 
        .ex_alu_ctrl(ex_alu_ctrl),
        .ex_alu_src_sel(ex_alu_src_sel),
        .ex_wb_sel(ex_wb_sel),
        .ex_reg_we(ex_reg_we),
        .ex_mem_we(ex_mem_we),
        .ex_zero_we(ex_zero_we),
        .ex_carry_we(ex_carry_we),
        .ex_is_jmp(ex_is_jmp),
        .ex_is_jz(ex_is_jz),
        .ex_pc(ex_pc),
        .ex_rd(ex_wa),          
        .ex_rs(ex_rs),               
        .ex_imm(ex_imm),
        .ex_valid()             
    );
    // --- STAGE 3: EXECUTE ---

    // 1. Register File
    register_file RF (
        .clk(clk),
        .rst(rst),
        .ra(ex_wa),    
        .rb(ex_rs),    
        .wa(ex_wa),            
        .wd(ex_wb_data),       
        .we(ex_reg_we),        
        .qa(ex_qa),
        .qb(ex_qb)
    );

    // 2. Operand MUX 
    mux2 operand_mux (
        .in0(ex_qb),
        .in1(ex_imm),
        .sel(ex_alu_src_sel),
        .out(ex_alu_b)
    );
    
    // 3. ALU
    alu execution_alu (
        .a(ex_qa),
        .b(ex_alu_b),
        .alu_ctrl(ex_alu_ctrl),
        .result(ex_alu_result),
        .carry(ex_carry),
        .zero(ex_zero)
    );

    // 4. Data Memory
    data_memory RAM (
        .clk(clk),
        .address(ex_alu_result), 
        .write_data(ex_qa),      
        .mem_we(ex_mem_we),
        .read_data(ex_mem_read_data)
    );

    // 5. Write-Back MUX 
    mux2 writeback_mux (
        .in0(ex_alu_result),
        .in1(ex_mem_read_data),
        .sel(ex_wb_sel),
        .out(ex_wb_data)
    );

    // 6. Flag Register
    flag_register FR (
        .clk(clk),
        .rst(rst),
        .zero_in(ex_zero),          // Raw combinational zero from ALU
        .carry_in(ex_carry),        // Raw combinational carry from ALU
        .zero_we(ex_zero_we),       // Control signal to update zero flag
        .carry_we(ex_carry_we),     // Control signal to update carry flag
        .zero_out(zero_out),        // Safely latched output directly to top-level port
        .carry_out(carry_out)       // Safely latched output directly to top-level port
    );

endmodule
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 04:32:21 PM
// Design Name: 
// Module Name: cpu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
