`timescale 1ns / 1ps

module pipeline_register (
    input wire clk,
    input wire rst,
    input wire flush,
    
    // Control signals from ID (Decoder)
    input wire [2:0] id_alu_ctrl,
    input wire id_alu_src_sel,
    input wire id_wb_sel,
    input wire id_reg_we,
    input wire id_mem_we,
    input wire id_zero_we,
    input wire id_carry_we,
    input wire id_is_jmp,
    input wire id_is_jz,
    
    // Data fields from ID
    input wire [3:0] id_pc,
    input wire [1:0] id_rd,
    input wire [1:0] id_rs,
    input wire [3:0] id_imm,
    input wire id_valid,
    
    // Control signals to EX
    output reg [2:0] ex_alu_ctrl,
    output reg ex_alu_src_sel,
    output reg ex_wb_sel,
    output reg ex_reg_we,
    output reg ex_mem_we,
    output reg ex_zero_we,
    output reg ex_carry_we,
    output reg ex_is_jmp,
    output reg ex_is_jz,
    
    // Data fields to EX
    output reg [3:0] ex_pc,
    output reg [1:0] ex_rd,
    output reg [1:0] ex_rs,
    output reg [3:0] ex_imm,
    output reg ex_valid
);

    always @(posedge clk) begin
        if (rst || flush) begin
            // Reset or flush: Load all-zero control signals to create a NOP
            ex_alu_ctrl    <= 3'd0;
            ex_alu_src_sel <= 1'b0;
            ex_wb_sel      <= 1'b0;
            ex_reg_we      <= 1'b0;
            ex_mem_we      <= 1'b0;
            ex_zero_we     <= 1'b0;
            ex_carry_we    <= 1'b0;
            ex_is_jmp      <= 1'b0;
            ex_is_jz       <= 1'b0;
            
            ex_pc          <= 4'b0000;
            ex_rd          <= 2'b00;
            ex_rs          <= 2'b00;
            ex_imm         <= 4'b0000;
            ex_valid       <= 1'b0;
        end else begin
            // Normal operation: pass decoded signals and data into the EX stage
            ex_alu_ctrl    <= id_alu_ctrl;
            ex_alu_src_sel <= id_alu_src_sel;
            ex_wb_sel      <= id_wb_sel;
            ex_reg_we      <= id_reg_we;
            ex_mem_we      <= id_mem_we;
            ex_zero_we     <= id_zero_we;
            ex_carry_we    <= id_carry_we;
            ex_is_jmp      <= id_is_jmp;
            ex_is_jz       <= id_is_jz;
            
            ex_pc          <= id_pc;
            ex_rd          <= id_rd;
            ex_rs          <= id_rs;
            ex_imm         <= id_imm;
            ex_valid       <= id_valid;
        end
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 04:23:45 PM
// Design Name: 
// Module Name: pipeline_register
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
