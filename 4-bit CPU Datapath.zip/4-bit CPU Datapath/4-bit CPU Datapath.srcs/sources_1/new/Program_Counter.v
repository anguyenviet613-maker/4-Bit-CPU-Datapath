`timescale 1ns / 1ps

module program_counter (
    input wire clk,
    input wire rst,
    input wire pc_en,          // enables the PC to update
    input wire [3:0] pc_next,  // the next address to move to
    output reg [3:0] pc_out    // The current address
);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pc_out <= 4'd0;    // reset back to line 0
        end else if (pc_en) begin
            pc_out <= pc_next; // load the next address on the clock edge
        end
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 12:09:35 AM
// Design Name: 
// Module Name: Program_Counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
