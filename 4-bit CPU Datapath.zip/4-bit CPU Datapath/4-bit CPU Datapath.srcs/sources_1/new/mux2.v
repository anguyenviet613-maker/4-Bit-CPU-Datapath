`timescale 1ns / 1ps

module mux2 (
    input wire [3:0] in0,
    input wire [3:0] in1,
    input wire sel,
    output wire [3:0] out
);
    assign out = sel ? in1 : in0;
endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 12:06:04 AM
// Design Name: 
// Module Name: mux2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
