`timescale 1ns / 1ps

module instruction_memory (
    input wire [3:0] address,
    output wire [11:0] instruction
);

    // declare memory array, 16 slots each are 12-bit
    reg [11:0] mem [0:15];

    // start by loading the program file
    initial begin
        // Use $readmemh to load "program.mem" into the mem array
        $readmemh("program.mem", mem);
    end

    // Combinational Read
    // Wire the instruction output to instantly read the requested address
    assign instruction = mem[address];

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 12:26:19 AM
// Design Name: 
// Module Name: instruction_memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
