`timescale 1ns / 1ps

module instruction_register (
    input wire clk,
    input wire rst,
    input wire ir_load,          // Fixed at 1 to fetch a new instruction every clock
    input wire flush,            // From branch unit: clears the register if a jump is taken
    input wire [3:0] pc_in,
    input wire [11:0] instruction_in,
    
    output reg [3:0] pc_out,
    output reg [11:0] instruction_out,
    output reg valid_out         // 0 means this slot is empty (a bubble)
);

    always @(posedge clk) begin
        if (rst) begin
            // Reset places control state in a known initial condition
            pc_out          <= 4'b0000;
            instruction_out <= 12'b0000_0000_0000; // NOP
            valid_out       <= 1'b0;               // Pipeline is initially empty
        end 
        else if (flush) begin
            // A taken jump means the fetched instruction is wrong and must be discarded
            pc_out          <= 4'b0000;
            instruction_out <= 12'b0000_0000_0000; // Convert to safe NOP
            valid_out       <= 1'b0;               // Mark as a bubble
        end 
        else if (ir_load) begin
            // Normal pipeline operation: pass data forward
            pc_out          <= pc_in;
            instruction_out <= instruction_in;
            valid_out       <= 1'b1;               // Valid instruction loaded
        end
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 04:21:17 PM
// Design Name: 
// Module Name: Instruction_Register
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

