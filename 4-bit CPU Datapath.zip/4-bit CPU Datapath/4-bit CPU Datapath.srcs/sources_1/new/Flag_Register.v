`timescale 1ns / 1ps

module flag_register (
    input wire clk,
    input wire rst,
    
    
    input wire zero_in,
    input wire carry_in,
    
   
    input wire zero_we,
    input wire carry_we,
    
    
    output reg zero_out,
    output reg carry_out
);

   
    always @(posedge clk) begin
        if (rst) begin
            zero_out  <= 1'b0;
            carry_out <= 1'b0;
        end else begin
            if (zero_we) begin
                zero_out <= zero_in;
            end
            if (carry_we) begin
                carry_out <= carry_in;
            end
        end
    end

endmodule
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 04:30:16 PM
// Design Name: 
// Module Name: Flag_Register
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
