`timescale 1ns / 1ps

module control_unit (
    // Inputs from ID stage (Instruction Decoder)
    input wire [3:0] opcode,
    
    // Inputs from EX stage (Branch Unit)
    input wire zero_flag,
    input wire ex_is_jmp,
    input wire ex_is_jz,

    // Outputs for ID/EX pipeline register
    output reg [2:0] alu_ctrl,
    output reg alu_src_sel,
    output reg wb_sel,
    output reg reg_we,
    output reg mem_we,
    output reg zero_we,
    output reg carry_we,
    output reg is_jmp,
    output reg is_jz,

    // Outputs to IF stage (Branch Unit decisions)
    output reg pc_sel,
    output reg flush
);

    // 1. INSTRUCTION DECODER (ID Stage)
    always @(*) begin
        // SAFE DEFAULTS (NOP state)
        alu_ctrl    = 3'd0;
        alu_src_sel = 1'b0;
        wb_sel      = 1'b0;
        reg_we      = 1'b0;
        mem_we      = 1'b0;
        zero_we     = 1'b0;
        carry_we    = 1'b0;
        is_jmp      = 1'b0;
        is_jz       = 1'b0;

        // OPCODE DECODING
        case (opcode)
            4'b0000: begin // ADD
                alu_ctrl = 3'd0; reg_we = 1'b1; zero_we = 1'b1; carry_we = 1'b1;
            end
            4'b0001: begin // SUB
                alu_ctrl = 3'd1; reg_we = 1'b1; zero_we = 1'b1; carry_we = 1'b1;
            end
            4'b0010: begin // AND
                alu_ctrl = 3'd2; reg_we = 1'b1; zero_we = 1'b1;
            end
            4'b0011: begin // OR
                alu_ctrl = 3'd3; reg_we = 1'b1; zero_we = 1'b1;
            end
            4'b0100: begin // XOR
                alu_ctrl = 3'd4; reg_we = 1'b1; zero_we = 1'b1;
            end
            4'b0101: begin // NOT
                alu_ctrl = 3'd5; reg_we = 1'b1; zero_we = 1'b1;
            end
            4'b0110: begin // LDI
                alu_ctrl = 3'd6; alu_src_sel = 1'b1; reg_we = 1'b1;
            end
            4'b0111: begin // MOV
                alu_ctrl = 3'd6; reg_we = 1'b1;
            end
            4'b1000: begin // LOAD
                alu_ctrl = 3'd6; alu_src_sel = 1'b1; wb_sel = 1'b1; reg_we = 1'b1;
            end
            4'b1001: begin // STORE
                alu_ctrl = 3'd6; alu_src_sel = 1'b1; mem_we = 1'b1;
            end
            4'b1010: begin // JMP
                is_jmp = 1'b1;
            end
            4'b1011: begin // JZ
                is_jz = 1'b1;
            end
            default: begin
                // Reserved opcodes remain safely at the default NOP state
            end
        endcase
    end

    // 2. BRANCH UNIT (EX Stage)
    always @(*) begin
        if (ex_is_jmp) begin
            // Unconditional jump taken
            pc_sel = 1'b1;
            flush  = 1'b1;
        end else if (ex_is_jz && zero_flag) begin
            // Conditional jump taken
            pc_sel = 1'b1;
            flush  = 1'b1;
        end else begin
            // No jump or condition not met
            pc_sel = 1'b0;
            flush  = 1'b0;
        end
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 01:03:11 AM
// Design Name: 
// Module Name: Control_Unit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
