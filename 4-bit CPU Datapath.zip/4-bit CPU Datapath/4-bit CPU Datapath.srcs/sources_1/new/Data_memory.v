`timescale 1ns / 1ps

module data_memory (
    input wire clk,
    input wire [3:0] address,
    input wire [3:0] write_data,
    input wire mem_we,
    output wire [3:0] read_data
);

    // declare memory array: 16 slots, each are 12-bit
    reg [3:0] mem [0:15];

    // Combinational Read: instantly output the data at the requested address
    assign read_data = mem[address];

    // Seq Write: update memory only on the rising clock edge if enabled
    always @(posedge clk) begin
        if (mem_we) begin
            mem[address] <= write_data;
        end
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 04:25:19 PM
// Design Name: 
// Module Name: Data_memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
