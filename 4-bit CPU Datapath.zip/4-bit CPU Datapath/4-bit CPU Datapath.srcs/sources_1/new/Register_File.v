`timescale 1ns / 1ps

module register_file (
    input wire clk,
    input wire rst,
    input wire [1:0] ra,     // Read Address A
    input wire [1:0] rb,     // Read Address B
    input wire [1:0] wa,     // Write Address
    input wire [3:0] wd,     // Write Data 
    input wire we,           // Write Enable 
    output reg [3:0] qa,     // Data output A
    output reg [3:0] qb      // Data output B
);

    // 4 registers (2 extra)
    reg [3:0] r0, r1, r2, r3;

    // COMBINATIONAL READ 
    always @(*) begin
        case(ra)
            2'd0: qa = r0;
            2'd1: qa = r1;
            2'd2: qa = r2;
            2'd3: qa = r3;
        endcase
        
        case(rb)
            2'd0: qb = r0;
            2'd1: qb = r1;
            2'd2: qb = r2;
            2'd3: qb = r3;
        endcase
    end

    // SEQUENTIAL WRITE  
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            // clear all memory on reset
            r0 <= 4'd0;
            r1 <= 4'd0;
            r2 <= 4'd0;
            r3 <= 4'd0;
        end else if (we) begin
            // write only when we is enabled
            case(wa)
                2'd0: r0 <= wd;
                2'd1: r1 <= wd;
                2'd2: r2 <= wd;
                2'd3: r3 <= wd;
            endcase
        end
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/07/2026 11:16:29 PM
// Design Name: 
// Module Name: Register_File
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
