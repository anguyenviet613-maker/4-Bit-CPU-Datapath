`timescale 1ns / 1ps

`timescale 1ns / 1ps

module tb_data_memory;
    reg clk = 0;
    reg [3:0] address = 0;
    reg [3:0] write_data = 0;
    reg mem_we = 0;
    wire [3:0] read_data;
    
    integer errors = 0;
    integer tests = 0;

    // clock 
    always #5 clk = ~clk;

    // Instantiate DUT
    data_memory DUT (
        .clk(clk),
        .address(address),
        .write_data(write_data),
        .mem_we(mem_we),
        .read_data(read_data)
    );

    // auto check
    task check;
        input [8*25:1] name;
        input [3:0] actual;
        input [3:0] expected;
        begin
            tests = tests + 1;
            if (actual === expected)
                $display("PASS %0s = %b", name, actual);
            else begin
                $display("FAIL %0s = %b (expected %b)", name, actual, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $display("\n===== tb_data_memory: Data Memory Test =====");
        
        // Write data to address 0
        address = 4'd0; write_data = 4'b1010; mem_we = 1;
        @(posedge clk); #1; 
        mem_we = 0; // Turn off write enable to secure the data
        
        // Verify combinational read
        check("Write/Read Addr 0        ", read_data, 4'b1010);

        // Write data to address 15
        address = 4'd15; write_data = 4'b0101; mem_we = 1;
        @(posedge clk); #1;
        mem_we = 0;
        check("Write/Read Addr 15       ", read_data, 4'b0101);

        // Verify mem_we = 0 does not allow overwriting
        address = 4'd0; write_data = 4'b1111; mem_we = 0; // Attempt unauthorized write
        @(posedge clk); #1; 
        check("mem_we=0 protects Addr 0 ", read_data, 4'b1010); // Should still hold old value

        // Combinational read test (changing address must instantly changes output)
        address = 4'd15; #1;
        check("Combinational Read Addr15", read_data, 4'b0101);
        
        if (errors == 0) $display("\ntb_data_memory PASSED: %0d of %0d checks OK", tests, tests);
        else $display("\ntb_data_memory FAILED: %0d of %0d checks failed", errors, tests);
        $finish;
    end
endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 11:41:28 PM
// Design Name: 
// Module Name: tb_data_memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
