`timescale 1ns / 1ps

module tb_mux2;
    //  Declare testbench variables
    reg [3:0] in0;
    reg [3:0] in1;
    reg sel;

    // Declare wire to debug output
    wire [3:0] out;

    integer errors = 0;
    integer tests = 0;

    // Instantiate DUT
    mux2 DUT (
        .in0(in0),
        .in1(in1),
        .sel(sel),
        .out(out)
    );

    // Self-checking task
    task check;
        input [8*15:1] name;
        input [3:0] expected;
        begin
            #1; // Wait 1ns for combinational logic to settle before reading 'out'
            tests = tests + 1;
            if (out === expected) begin
                $display("PASS %0s: out = %b", name, out);
            end else begin
                $display("FAIL %0s: out = %b (expected %b)", name, out, expected);
                errors = errors + 1;
            end
        end
    endtask

    // Apply Input
    initial begin
        $display("\n===== tb_mux2: 2-to-1 Multiplexer Test =====");

        // Setup distinctive test values
        in0 = 4'b1010; // Decimal 10
        in1 = 4'b0011; // Decimal 3

        // Test Case 1: Select input 0
        sel = 1'b0;
        check("Select in0     ", 4'b1010);

        // Test Case 2: Select input 1
        sel = 1'b1;
        check("Select in1     ", 4'b0011);

        // Change input values dynamically to ensure the MUX reacts to data changes
        in0 = 4'b1111;
        in1 = 4'b0000;

        // Test Case 3: Select input 0 with new data
        sel = 1'b0;
        check("Select new in0 ", 4'b1111);

        // Test Case 4: Select input 1 with new data
        sel = 1'b1;
        check("Select new in1 ", 4'b0000);

        if (errors == 0)
            $display("\ntb_mux2 PASSED: %0d of %0d checks OK", tests, tests);
        else
            $display("\ntb_mux2 FAILED: %0d of %0d checks failed", errors, tests);

        $finish;
    end
endmodule

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/08/2026 11:47:37 PM
// Design Name: 
// Module Name: tb_mux
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
